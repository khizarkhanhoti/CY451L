interface MyAction {
  type: string;
  payload: any;
}

export default MyAction;
